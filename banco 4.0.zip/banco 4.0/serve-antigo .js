// =====================================================
// BANCO 4.0 — SERVIDOR PRINCIPAL
// =====================================================

require('dotenv').config();

const express = require('express');
const http = require('http');
const path = require('path');
const crypto = require('crypto');
const cors = require('cors');
const WebSocket = require('ws');
const { Pool } = require('pg');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const PORT = Number(process.env.PORT) || 3000;
const MASTER_CREATOR_KEY = process.env.MASTER_CREATOR_KEY || '';

if (!MASTER_CREATOR_KEY) {
    console.warn('⚠️  MASTER_CREATOR_KEY não definida no .env; auditoria global desativada.');
}

// =====================================================
// BANCO DE DADOS
// =====================================================

const pool = new Pool({
    connectionString: process.env.DATABASE_URL || 'postgresql://usuario:senha@localhost:5432/bankcorp',
    ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : false
});

pool.on('error', (err) => {
    console.error('❌ Erro inesperado no banco de dados:', err.message);
});

// =====================================================
// CONFIGURAÇÕES DO EXPRESS
// =====================================================

app.disable('x-powered-by');
app.use(cors({ origin: process.env.CORS_ORIGIN || false }));
app.use(express.json({ limit: '1mb' }));

// Cabeçalhos básicos de segurança
app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    next();
});

app.use(express.static(path.join(__dirname, 'public')));

// =====================================================
// WEBSOCKET — CONEXÕES EM TEMPO REAL
// =====================================================

function contarConexoesAtivas() {
    let total = 0;
    wss.clients.forEach((cliente) => {
        if (cliente.readyState === WebSocket.OPEN) {
            total++;
        }
    });
    return total;
}

wss.on('connection', (ws) => {
    ws.isAlive = true;
    enviarMetricas();

    ws.on('pong', () => {
        ws.isAlive = true;
    });

    ws.on('close', () => {
        enviarMetricas();
    });

    ws.on('error', (erro) => {
        console.warn('⚠️  Erro no cliente WebSocket:', erro.message);
    });
});

// Verifica conexões zumbis a cada 30 segundos
const intervaloHeartbeat = setInterval(() => {
    wss.clients.forEach((ws) => {
        if (ws.isAlive === false) return ws.terminate();
        ws.isAlive = false;
        ws.ping();
    });
}, 30000);

function enviarMetricas() {
    enviarParaTodos({
        type: 'METRICS_UPDATE',
        conexoesAtivas: contarConexoesAtivas()
    });
}

function enviarParaTodos(dados) {
    const mensagem = JSON.stringify(dados);

    wss.clients.forEach((cliente) => {
        if (cliente.readyState === WebSocket.OPEN) {
            cliente.send(mensagem);
        }
    });
}

// =====================================================
// ROTAS BÁSICAS
// =====================================================

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/api/health', async (req, res) => {
    let bancoOnline = false;

    try {
        await pool.query('SELECT 1');
        bancoOnline = true;
    } catch {
        bancoOnline = false;
    }

    res.status(bancoOnline ? 200 : 503).json({
        status: bancoOnline ? 'ok' : 'degradado',
        bancoDados: bancoOnline ? 'conectado' : 'indisponível',
        mensagem: 'Servidor BankCorp Enterprise ativo.',
        conexoesAtivas: contarConexoesAtivas(),
        hora: new Date().toISOString()
    });
});

// =====================================================
// TRANSFERÊNCIAS
// =====================================================

app.post('/api/transferencias', async (req, res) => {
    try {
        const {
            remetenteId,
            destinatarioIdentificador,
            valor,
            tipo,
            moedaOrigem,
            moedaDestino
        } = req.body || {};

        if (!remetenteId || !destinatarioIdentificador || !valor || !tipo) {
            return res.status(400).json({
                status: 'erro',
                mensagem: 'Preencha remetente, destinatário, valor e tipo.'
            });
        }

        const valorNumerico = Number(valor);

        if (!Number.isFinite(valorNumerico) || valorNumerico <= 0) {
            return res.status(400).json({
                status: 'erro',
                mensagem: 'O valor da transferência deve ser maior que zero.'
            });
        }

        const query = `
            INSERT INTO transferencias
            (
                remetente_id,
                destinatario_identificador,
                valor,
                tipo,
                moeda_origem,
                moeda_destino,
                data_hora
            )
            VALUES ($1, $2, $3, $4, $5, $6, NOW())
            RETURNING id, tipo, moeda_origem, moeda_destino, data_hora
        `;

        const valores = [
            String(remetenteId).trim().slice(0, 100),
            String(destinatarioIdentificador).trim().slice(0, 140),
            valorNumerico,
            String(tipo).trim().slice(0, 50),
            String(moedaOrigem || 'BRL').trim().toUpperCase().slice(0, 10),
            String(moedaDestino || 'BRL').trim().toUpperCase().slice(0, 10)
        ];

        const resultado = await pool.query(query, valores);
        const transferencia = resultado.rows[0];

        // Notifica sem expor CPF, IDs ou valores financeiros a outros clientes
        enviarParaTodos({
            type: 'NOVA_TRANSFERENCIA',
            id: transferencia.id,
            tipo: transferencia.tipo,
            dataHora: transferencia.data_hora
        });

        res.status(201).json({
            status: 'sucesso',
            mensagem: 'Transferência registrada com sucesso.',
            transferencia
        });
    } catch (erro) {
        console.error('❌ Erro ao registrar transferência:', erro.message);

        res.status(500).json({
            status: 'erro',
            mensagem: 'Erro ao processar a transferência.'
        });
    }
});

app.get('/api/transferencias', async (req, res) => {
    try {
        const limite = Math.max(1, Math.min(Number(req.query.limite) || 50, 200));

        const query = `
            SELECT
                id,
                remetente_id,
                destinatario_identificador,
                valor,
                tipo,
                moeda_origem,
                moeda_destino,
                data_hora
            FROM transferencias
            ORDER BY data_hora DESC
            LIMIT $1
        `;

        const resultado = await pool.query(query, [limite]);

        res.json({
            status: 'sucesso',
            total: resultado.rowCount,
            transferencias: resultado.rows
        });
    } catch (erro) {
        console.error('❌ Erro ao listar transferências:', erro.message);

        res.status(500).json({
            status: 'erro',
            mensagem: 'Erro ao buscar transferências.'
        });
    }
});

// =====================================================
// CRIPTOMOEDAS (COM CACHE DE 60s E TIMEOUT)
// =====================================================

let cacheCrypto = {
    dados: null,
    atualizadoEm: 0
};

app.get('/api/crypto/market', async (req, res) => {
    const agora = Date.now();

    if (cacheCrypto.dados && agora - cacheCrypto.atualizadoEm < 60000) {
        return res.json(cacheCrypto.dados);
    }

    const controle = new AbortController();
    const temporizador = setTimeout(() => controle.abort(), 10000);

    try {
        const resposta = await fetch(
            'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=25&page=1&sparkline=true',
            {
                signal: controle.signal,
                headers: { Accept: 'application/json' }
            }
        );

        if (!resposta.ok) {
            throw new Error(`CoinGecko respondeu com status ${resposta.status}`);
        }

        const dados = await resposta.json();

        cacheCrypto = {
            dados,
            atualizadoEm: Date.now()
        };

        res.json(dados);
    } catch (erro) {
        console.error('❌ Erro ao buscar criptomoedas:', erro.message);

        if (cacheCrypto.dados) {
            return res.json(cacheCrypto.dados);
        }

        res.status(502).json({
            status: 'erro',
            mensagem: 'Não foi possível obter as cotações das criptomoedas.'
        });
    } finally {
        clearTimeout(temporizador);
    }
});

// =====================================================
// AUDITORIA DO CRIADOR
// =====================================================

function verificarChaveCriador(req, res, next) {
    const chave = String(req.headers['x-creator-key'] || '');

    if (!MASTER_CREATOR_KEY || !chave) {
        return res.status(403).json({
            status: 'erro',
            mensagem: 'Acesso negado.'
        });
    }

    const bufferRecebido = Buffer.from(chave);
    const bufferEsperado = Buffer.from(MASTER_CREATOR_KEY);

    if (
        bufferRecebido.length !== bufferEsperado.length ||
        !crypto.timingSafeEqual(bufferRecebido, bufferEsperado)
    ) {
        return res.status(403).json({
            status: 'erro',
            mensagem: 'Acesso negado.'
        });
    }

    next();
}

app.get('/api/admin/auditoria-global', verificarChaveCriador, async (req, res) => {
    try {
        const query = `
            SELECT
                id,
                remetente_id,
                destinatario_identificador,
                valor,
                tipo,
                moeda_origem,
                moeda_destino,
                data_hora
            FROM transferencias
            ORDER BY data_hora DESC
            LIMIT 500
        `;

        const resultado = await pool.query(query);

        res.json({
            status: 'sucesso',
            conexoesAtivas: contarConexoesAtivas(),
            totalAuditado: resultado.rowCount,
            transferencias: resultado.rows
        });
    } catch (erro) {
        console.error('❌ Erro na auditoria global:', erro.message);

        res.status(500).json({
            status: 'erro',
            mensagem: 'Erro ao buscar relatório de auditoria.'
        });
    }
});

// =====================================================
// ROTA NÃO ENCONTRADA E ERROS GLOBAIS
// =====================================================

app.use((req, res) => {
    res.status(404).json({
        status: 'erro',
        mensagem: 'Rota não encontrada.'
    });
});

app.use((erro, req, res, next) => {
    console.error('❌ Erro interno:', erro.stack);

    res.status(500).json({
        status: 'erro',
        mensagem: 'Erro interno do servidor.'
    });
});

// =====================================================
// INICIAR E ENCERRAR SERVIDOR
// =====================================================

server.listen(PORT, () => {
    console.log('====================================');
    console.log('🚀 SERVIDOR BANKCORP ENTERPRISE');
    console.log(`🌐 http://localhost:${PORT}`);
    console.log(`❤️  http://localhost:${PORT}/api/health`);
    console.log('====================================');
});

async function encerrarServidor() {
    console.log('\n🛑 Encerrando servidor...');
    clearInterval(intervaloHeartbeat);

    wss.clients.forEach((ws) => ws.close());

    try {
        await pool.end();
        server.close(() => {
            console.log('✅ Servidor encerrado com segurança.');
            process.exit(0);
        });
    } catch (erro) {
        console.error('❌ Erro ao encerrar:', erro.message);
        process.exit(1);
    }
}

process.on('SIGINT', encerrarServidor);
process.on('SIGTERM', encerrarServidor);