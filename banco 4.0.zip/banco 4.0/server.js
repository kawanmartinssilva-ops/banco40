// =====================================================
// BANCO 4.0 — SERVIDOR PRINCIPAL
// =====================================================

require('dotenv').config();

const express = require('express');
const http = require('http');
const path = require('path');
const cors = require('cors');
const WebSocket = require('ws');
const { Pool } = require('pg');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const PORT = process.env.PORT || 3000;

// =====================================================
// BANCO DE DADOS POSTGRESQL
// =====================================================

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

pool.on('error', (erro) => {
    console.error('❌ Erro no banco de dados:', erro.message);
});

// =====================================================
// CONFIGURAÇÕES DO SERVIDOR
// =====================================================

app.disable('x-powered-by');

app.use(cors());
app.use(express.json({ limit: '1mb' }));

app.use(express.static(path.join(__dirname, 'public')));

// =====================================================
// WEBSOCKET
// =====================================================

wss.on('connection', (ws) => {
    console.log('🔌 Novo cliente conectado.');

    ws.on('close', () => {
        console.log('🔌 Cliente desconectado.');
    });

    ws.on('error', (erro) => {
        console.warn('⚠️ Erro no WebSocket:', erro.message);
    });
});

function enviarParaTodos(dados) {
    const mensagem = JSON.stringify(dados);

    wss.clients.forEach((cliente) => {
        if (cliente.readyState === WebSocket.OPEN) {
            cliente.send(mensagem);
        }
    });
}

// =====================================================
// ROTAS BÁSICAS
// =====================================================

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/api/health', async (req, res) => {
    let bancoOnline = false;

    try {
        await pool.query('SELECT 1');
        bancoOnline = true;
    } catch (erro) {
        console.error('❌ Banco indisponível:', erro.message);
        bancoOnline = false;
    }

    res.status(bancoOnline ? 200 : 503).json({
        status: bancoOnline ? 'ok' : 'degradado',
        bancoDados: bancoOnline ? 'conectado' : 'indisponível',
        mensagem: 'Servidor BankCorp Enterprise ativo.',
        hora: new Date().toISOString()
    });
});

// =====================================================
// TRANSFERÊNCIAS
// =====================================================

app.post('/api/transferencias', async (req, res) => {
    try {
        const {
            remetenteId,
            destinatarioIdentificador,
            valor,
            tipo,
            moedaOrigem,
            moedaDestino
        } = req.body || {};

        if (!remetenteId || !destinatarioIdentificador || !valor || !tipo) {
            return res.status(400).json({
                status: 'erro',
                mensagem: 'Preencha remetente, destinatário, valor e tipo.'
            });
        }

        const valorNumerico = Number(valor);

        if (!Number.isFinite(valorNumerico) || valorNumerico <= 0) {
            return res.status(400).json({
                status: 'erro',
                mensagem: 'O valor deve ser maior que zero.'
            });
        }

        const query = `
            INSERT INTO transferencias
            (
                remetente_id,
                destinatario_identificador,
                valor,
                tipo,
                moeda_origem,
                moeda_destino,
                data_hora
            )
            VALUES ($1, $2, $3, $4, $5, $6, NOW())
            RETURNING *
        `;

        const valores = [
            String(remetenteId).trim(),
            String(destinatarioIdentificador).trim(),
            valorNumerico,
            String(tipo).trim(),
            String(moedaOrigem || 'BRL').trim().toUpperCase(),
            String(moedaDestino || 'BRL').trim().toUpperCase()
        ];

        const resultado = await pool.query(query, valores);
        const transferencia = resultado.rows[0];

        enviarParaTodos({
            type: 'NOVA_TRANSFERENCIA',
            dados: transferencia
        });

        res.status(201).json({
            status: 'sucesso',
            mensagem: 'Transferência registrada com sucesso.',
            transferencia
        });

    } catch (erro) {
        console.error('❌ Erro ao registrar transferência:', erro.message);

        res.status(500).json({
            status: 'erro',
            mensagem: 'Erro ao processar a transferência.'
        });
    }
});

app.get('/api/transferencias', async (req, res) => {
    try {
        const limite = Math.min(Number(req.query.limite) || 50, 200);

        const query = `
            SELECT *
            FROM transferencias
            ORDER BY data_hora DESC
            LIMIT $1
        `;

        const resultado = await pool.query(query, [limite]);

        res.json({
            status: 'sucesso',
            total: resultado.rowCount,
            transferencias: resultado.rows
        });

    } catch (erro) {
        console.error('❌ Erro ao listar transferências:', erro.message);

        res.status(500).json({
            status: 'erro',
            mensagem: 'Erro ao buscar transferências.'
        });
    }
});

// =====================================================
// CRIPTOMOEDAS
// =====================================================

app.get('/api/crypto/market', async (req, res) => {
    try {
        const resposta = await fetch(
            'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=25&page=1&sparkline=true'
        );

        if (!resposta.ok) {
            throw new Error(`CoinGecko respondeu com status ${resposta.status}`);
        }

        const dados = await resposta.json();

        res.json(dados);

    } catch (erro) {
        console.error('❌ Erro ao buscar criptomoedas:', erro.message);

        res.status(502).json({
            status: 'erro',
            mensagem: 'Não foi possível obter as cotações.'
        });
    }
});

// =====================================================
// ROTAS NÃO ENCONTRADAS E ERROS
// =====================================================

app.use((req, res) => {
    res.status(404).json({
        status: 'erro',
        mensagem: 'Rota não encontrada.'
    });
});

app.use((erro, req, res, next) => {
    console.error('❌ Erro interno:', erro.stack);

    res.status(500).json({
        status: 'erro',
        mensagem: 'Erro interno do servidor.'
    });
});

// =====================================================
// INICIAR SERVIDOR
// =====================================================

server.listen(PORT, () => {
    console.log('====================================');
    console.log('🚀 SERVIDOR BANKCORP ENTERPRISE');
    console.log(`🌐 http://localhost:${PORT}`);
    console.log(`❤️  http://localhost:${PORT}/api/health`);
    console.log('====================================');
});

// =====================================================
// ENCERRAR COM SEGURANÇA
// =====================================================

async function encerrarServidor() {
    console.log('\n🛑 Encerrando servidor...');

    try {
        await pool.end();
        server.close(() => {
            console.log('✅ Servidor encerrado.');
            process.exit(0);
        });
    } catch (erro) {
        console.error('❌ Erro ao encerrar:', erro.message);
        process.exit(1);
    }
}

process.on('SIGINT', encerrarServidor);
process.on('SIGTERM', encerrarServidor);