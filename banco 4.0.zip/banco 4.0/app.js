"use strict";

(() => {
    const CONFIG = {
        apiLocal: "/api/crypto/market",
        apiPublica:
            "https://api.coingecko.com/api/v3/coins/markets" +
            "?vs_currency=usd&order=market_cap_desc" +
            "&per_page=25&page=1&sparkline=true",

        tempoLimite: 12000,
        intervaloCache: 60000,

        // Ative somente se o servidor aceitar WebSocket na mesma origem.
        websocketAtivo: false
    };

    const estado = {
        moedas: [],
        carregando: false,
        atualizadoEm: 0,
        graficos: [],
        cotacaoBRL: null,
        moedaSelecionada: null,
        focoAnterior: null,
        socket: null
    };

    const porId = id => document.getElementById(id);
    const numeroValido = valor =>
        typeof valor === "number" && Number.isFinite(valor);

    const formatadorUSD = new Intl.NumberFormat("pt-BR", {
        style: "currency",
        currency: "USD",
        maximumFractionDigits: 8
    });

    const formatadorBRL = new Intl.NumberFormat("pt-BR", {
        style: "currency",
        currency: "BRL",
        maximumFractionDigits: 8
    });

    function dinheiro(valor, moeda = "USD") {
        if (!numeroValido(valor)) return "Indisponível";
        return (moeda === "BRL" ? formatadorBRL : formatadorUSD)
            .format(valor);
    }

    function avisar(mensagem) {
        if (typeof window.exibirToast === "function") {
            window.exibirToast(mensagem);
        } else {
            window.alert(mensagem);
        }
    }

    function criar(tag, texto, classe) {
        const elemento = document.createElement(tag);
        if (texto !== undefined) elemento.textContent = texto;
        if (classe) elemento.className = classe;
        return elemento;
    }

    async function buscarJSON(url) {
        const controle = new AbortController();
        const temporizador = setTimeout(
            () => controle.abort(),
            CONFIG.tempoLimite
        );

        try {
            const resposta = await fetch(url, {
                signal: controle.signal,
                headers: { Accept: "application/json" }
            });

            if (!resposta.ok) {
                throw new Error(
                    resposta.status === 429
                        ? "Limite de consultas atingido. Tente mais tarde."
                        : `Erro HTTP ${resposta.status} na consulta.`
                );
            }

            const dados = await resposta.json();

            if (
                !Array.isArray(dados) ||
                !dados.every(item =>
                    item &&
                    typeof item === "object" &&
                    typeof item.id === "string"
                )
            ) {
                throw new Error("Formato de resposta inesperado.");
            }

            return dados;
        } finally {
            clearTimeout(temporizador);
        }
    }

    function mensagemTabela(texto) {
        const tabela = porId("listaCryptoBody");
        if (!tabela) return;

        const linha = criar("tr");
        const celula = criar("td", texto);

        celula.colSpan = 7;
        celula.style.textAlign = "center";

        linha.append(celula);
        tabela.replaceChildren(linha);
    }

    function renderizarTabelaCripto() {
        const tabela = porId("listaCryptoBody");
        if (!tabela) return;

        if (!estado.moedas.length) {
            mensagemTabela("Nenhuma criptomoeda disponível.");
            return;
        }

        const fragmento = document.createDocumentFragment();

        estado.moedas.forEach((moeda, indice) => {
            const linha = criar("tr");
            const nome = String(moeda.name ?? moeda.id);
            const simbolo = String(moeda.symbol ?? "").toUpperCase();
            const variacao = moeda.price_change_percentage_24h;
            const temVariacao = numeroValido(variacao);

            const precoBRL =
                numeroValido(moeda.current_price) &&
                numeroValido(estado.cotacaoBRL)
                    ? moeda.current_price * estado.cotacaoBRL
                    : null;

            linha.append(
                criar("td", String(indice + 1)),
                criar("td", `${nome} (${simbolo})`),
                criar("td", dinheiro(moeda.current_price)),
                criar(
                    "td",
                    precoBRL === null
                        ? "Defina o câmbio em Detalhes"
                        : `${dinheiro(precoBRL, "BRL")} (simulado)`
                ),
                criar(
                    "td",
                    temVariacao ? `${variacao.toFixed(2)}%` : "Sem dados",
                    temVariacao ? (variacao >= 0 ? "green" : "red") : ""
                ),
                criar(
                    "td",
                    !temVariacao ? "Sem dados" :
                    variacao > 0 ? "Alta" :
                    variacao < 0 ? "Baixa" : "Estável"
                )
            );

            const acao = criar("td");
            const botao = criar("button", "Ver gráficos", "btn-green");

            botao.type = "button";
            botao.addEventListener("click", () => abrirDetalhes(moeda.id));

            acao.append(botao);
            linha.append(acao);
            fragmento.append(linha);
        });

        tabela.replaceChildren(fragmento);
    }

    async function carregarCriptomoedas() {
        if (!porId("listaCryptoBody") || estado.carregando) return;

        if (
            estado.moedas.length &&
            Date.now() - estado.atualizadoEm < CONFIG.intervaloCache
        ) {
            renderizarTabelaCripto();
            return;
        }

        estado.carregando = true;

        const tabela = porId("listaCryptoBody");
        tabela.setAttribute("aria-busy", "true");

        if (!estado.moedas.length) {
            mensagemTabela("Consultando criptomoedas...");
        }

        try {
            let dados;

            if (["http:", "https:"].includes(location.protocol)) {
                try {
                    dados = await buscarJSON(CONFIG.apiLocal);
                } catch (erroLocal) {
                    console.warn(
                        "Consulta local indisponível; tentando a API pública.",
                        erroLocal
                    );
                    dados = await buscarJSON(CONFIG.apiPublica);
                }
            } else {
                dados = await buscarJSON(CONFIG.apiPublica);
            }

            estado.moedas = dados.slice(0, 25);
            estado.atualizadoEm = Date.now();

            renderizarTabelaCripto();
        } catch (erro) {
            console.error("Falha ao carregar criptomoedas:", erro);

            const mensagem = erro.name === "AbortError"
                ? "A consulta demorou demais. Tente novamente."
                : erro.message || "Não foi possível carregar as cotações.";

            if (estado.moedas.length) {
                renderizarTabelaCripto();
                avisar(`${mensagem} Mantendo os dados anteriores.`);
            } else {
                mensagemTabela(mensagem);
            }
        } finally {
            estado.carregando = false;
            tabela.removeAttribute("aria-busy");
        }
    }

    // Demonstração: não autentica nem protege dados no servidor.
    function realizarLogin() {
        const nome = porId("adminNome");
        const cpf = porId("adminCPF");
        const senha = porId("adminSenha");
        const login = porId("loginScreen");
        const painel = porId("appContainer");

        if (!nome || !cpf || !senha || !login || !painel) {
            avisar("A estrutura do login está incompleta.");
            return;
        }

        const nomeInformado = nome.value.trim();
        const documento = cpf.value.replace(/\D/g, "");

        if (!nomeInformado || !documento || !senha.value) {
            avisar("Preencha todos os campos.");
            return;
        }

        if (documento.length !== 11) {
            avisar("Informe um CPF com 11 números.");
            return;
        }

        if (porId("adminUserDisplay")) {
            porId("adminUserDisplay").textContent = nomeInformado;
        }

        if (porId("adminCpfDisplay")) {
            porId("adminCpfDisplay").textContent =
                `CPF: ***.***.***-${documento.slice(-2)}`;
        }

        senha.value = "";
        login.style.display = "none";
        painel.style.display = "flex";

        if (typeof window.renderizarClientes === "function") {
            window.renderizarClientes();
        }

        // Redimensiona os gráficos financeiros criados com o painel oculto.
        requestAnimationFrame(() => {
            ["barChart", "pieChart"].forEach(id => {
                const canvas = porId(id);
                if (canvas && window.Chart?.getChart) {
                    window.Chart.getChart(canvas)?.resize();
                }
            });
        });

        avisar("Modo demonstrativo iniciado. Não utilize dados reais.");
        porId("btnAndamento")?.focus();
    }

    function destruirGraficos() {
        estado.graficos.forEach(grafico => grafico.destroy());
        estado.graficos = [];
    }

    function atualizarSimulacao() {
        const moeda = estado.moedaSelecionada;
        const cambio = Number(porId("cryptoCambio")?.value);
        const investimento = Number(porId("inputInvestimento")?.value);

        estado.cotacaoBRL =
            Number.isFinite(cambio) && cambio > 0 ? cambio : null;

        const preco = numeroValido(moeda?.current_price) &&
            estado.cotacaoBRL !== null
                ? moeda.current_price * estado.cotacaoBRL
                : null;

        const campoPreco = porId("cryptoPrecoBRL");
        const resultado = porId("resultadoSimulacao");

        if (campoPreco) {
            campoPreco.textContent = preco !== null
                ? `Preço convertido: ${dinheiro(preco, "BRL")} — simulação.`
                : "Informe o câmbio para simular o preço em reais.";
        }

        if (resultado) {
            resultado.textContent =
                preco > 0 &&
                Number.isFinite(investimento) &&
                investimento > 0
                    ? `Estimativa: ${(investimento / preco).toLocaleString(
                        "pt-BR",
                        { maximumFractionDigits: 8 }
                    )} unidades, sem taxas ou spread.`
                    : "";
        }

        renderizarTabelaCripto();
    }

    function adicionarGrafico(container, titulo, tipo, labels, dados) {
        const caixa = criar("section", undefined, "chart-box");
        caixa.append(criar("h3", titulo));
        container.append(caixa);

        if (
            !dados.length ||
            !dados.every(valor => numeroValido(valor) && valor >= 0) ||
            (["pie", "doughnut"].includes(tipo) &&
                dados.every(valor => valor === 0))
        ) {
            caixa.append(criar("p", "Dados indisponíveis para este gráfico."));
            return;
        }

        const moldura = criar("div");
        moldura.style.position = "relative";
        moldura.style.height = "260px";

        const canvas = criar("canvas");
        canvas.setAttribute("role", "img");
        canvas.setAttribute("aria-label", titulo);

        moldura.append(canvas);
        caixa.append(moldura);

        const resumo = criar(
            "p",
            ["line"].includes(tipo)
                ? `${dados.length} amostras, em ordem de recebimento.`
                : labels.map((label, i) =>
                    `${label}: ${dados[i].toLocaleString("pt-BR")}`
                ).join(" | ")
        );

        caixa.append(resumo);

        estado.graficos.push(new Chart(canvas, {
            type: tipo,
            data: {
                labels,
                datasets: [{
                    label: titulo,
                    data: dados,
                    borderColor: tipo === "line" ? "#4ade80" : undefined,
                    backgroundColor: tipo === "line"
                        ? "rgba(74, 222, 128, 0.15)"
                        : ["#60a5fa", "#4ade80", "#fbbf24"],
                    pointRadius: tipo === "line" ? 0 : undefined
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: false,
                plugins: {
                    legend: {
                        display: ["pie", "doughnut"].includes(tipo),
                        labels: { color: "#e2e8f0" }
                    }
                },
                scales: ["line", "bar"].includes(tipo)
                    ? {
                        x: {
                            ticks: { color: "#a8b7cc", maxTicksLimit: 6 }
                        },
                        y: {
                            ticks: { color: "#a8b7cc" },
                            beginAtZero: tipo === "bar"
                        }
                    }
                    : {}
            }
        }));
    }

    function renderizarGraficosModal(moeda, container) {
        if (typeof window.Chart !== "function") {
            container.append(criar(
                "p",
                "A biblioteca Chart.js não carregou. Os detalhes continuam disponíveis."
            ));
            return;
        }

        const historico = moeda.sparkline_in_7d?.price;
        const serieValida = Array.isArray(historico) &&
            historico.every(valor => numeroValido(valor) && valor >= 0);

        adicionarGrafico(
            container,
            "Histórico de preços — USD, sequência de 7 dias",
            "line",
            serieValida ? historico.map((_, i) => String(i + 1)) : [],
            serieValida ? historico : []
        );

        adicionarGrafico(
            container,
            "Mínima e máxima em 24h e preço atual — USD",
            "bar",
            ["Mínima 24h", "Preço atual", "Máxima 24h"],
            [moeda.low_24h, moeda.current_price, moeda.high_24h]
        );

        const circulante = moeda.circulating_supply;
        const total = moeda.total_supply;
        const maximo = moeda.max_supply;

        adicionarGrafico(
            container,
            "Oferta em relação ao total informado — unidades",
            "pie",
            ["Em circulação", "Diferença até a oferta total"],
            numeroValido(circulante) &&
            numeroValido(total) &&
            circulante >= 0 &&
            total >= circulante
                ? [circulante, total - circulante]
                : []
        );

        adicionarGrafico(
            container,
            "Oferta total em relação à máxima — unidades",
            "doughnut",
            ["Oferta total", "Diferença até a oferta máxima"],
            numeroValido(total) &&
            numeroValido(maximo) &&
            total >= 0 &&
            maximo >= total
                ? [total, maximo - total]
                : []
        );
    }

    function abrirDetalhes(id) {
        const moeda = estado.moedas.find(item => item.id === id);
        const modal = porId("cryptoModal");
        const conteudo = porId("cryptoModalContent");

        if (!moeda || !modal || !conteudo) {
            avisar("Não foi possível abrir os detalhes.");
            return;
        }

        destruirGraficos();
        estado.moedaSelecionada = moeda;

        if (modal.style.display !== "block") {
            estado.focoAnterior = document.activeElement;
        }

        conteudo.replaceChildren();

        const titulo = criar("h2", String(moeda.name ?? moeda.id));
        const variacao = moeda.price_change_percentage_24h;

        conteudo.append(
            titulo,
            criar("p", `Preço: ${dinheiro(moeda.current_price)}`),
            criar(
                "p",
                numeroValido(variacao)
                    ? `Variação em 24h: ${variacao.toFixed(2)}%.`
                    : "Variação em 24h indisponível."
            ),
            criar(
                "p",
                `Consulta recebida em: ${
                    new Date(estado.atualizadoEm).toLocaleString("pt-BR")
                }. Os preços não são atualizados continuamente.`
            )
        );

        const simulacao = criar("section", undefined, "chart-box");
        simulacao.append(criar("h3", "Simulação de investimento"));

        const labelCambio = criar("label", "Câmbio informado: R$ por US$ 1");
        labelCambio.htmlFor = "cryptoCambio";

        const cambio = criar("input");
        cambio.id = "cryptoCambio";
        cambio.type = "number";
        cambio.min = "0.000001";
        cambio.step = "any";
        cambio.placeholder = "Informe a cotação para a simulação";
        cambio.value = estado.cotacaoBRL ?? "";

        const precoBRL = criar("p");
        precoBRL.id = "cryptoPrecoBRL";

        const labelValor = criar("label", "Valor a investir em reais");
        labelValor.htmlFor = "inputInvestimento";

        const investimento = criar("input");
        investimento.id = "inputInvestimento";
        investimento.type = "number";
        investimento.min = "0.01";
        investimento.step = "0.01";

        const resultado = criar("p");
        resultado.id = "resultadoSimulacao";
        resultado.setAttribute("aria-live", "polite");

        simulacao.append(
            labelCambio, cambio, precoBRL,
            labelValor, investimento, resultado
        );

        cambio.addEventListener("input", atualizarSimulacao);
        investimento.addEventListener("input", atualizarSimulacao);

        const graficos = criar("div", undefined, "charts-grid");
        graficos.style.marginTop = "20px";

        conteudo.append(simulacao, graficos);
        modal.style.display = "block";

        atualizarSimulacao();
        renderizarGraficosModal(moeda, graficos);

        const fechar = modal.querySelector("button");
        if (fechar) {
            fechar.onclick = fecharModalCrypto;
            fechar.focus();
        }
    }

    function fecharModalCrypto() {
        const modal = porId("cryptoModal");
        if (modal) modal.style.display = "none";

        destruirGraficos();
        estado.moedaSelecionada = null;

        if (estado.focoAnterior?.isConnected) {
            estado.focoAnterior.focus();
        }
    }

    function conectarWebSocket() {
        if (
            !CONFIG.websocketAtivo ||
            !["http:", "https:"].includes(location.protocol)
        ) return;

        try {
            const url = new URL(location.origin);
            url.protocol = location.protocol === "https:" ? "wss:" : "ws:";

            const socket = new WebSocket(url);
            estado.socket = socket;

            socket.addEventListener("message", evento => {
                try {
                    const mensagem = JSON.parse(evento.data);
                    if (!mensagem || typeof mensagem !== "object") return;

                    if (mensagem.type === "METRICS_UPDATE") {
                        console.info(
                            "Conexões ativas:",
                            mensagem.conexoesAtivas
                        );
                    }

                    if (mensagem.type === "NOVA_TRANSFERENCIA") {
                        // Não registra dados pessoais ou financeiros no console.
                        avisar("O servidor informou uma nova transferência.");
                    }
                } catch {
                    console.warn("Mensagem WebSocket ignorada: formato inválido.");
                }
            });

            socket.addEventListener("error", () => {
                console.warn("WebSocket indisponível.");
            });

            socket.addEventListener("close", () => {
                estado.socket = null;
            });
        } catch (erro) {
            console.warn("Não foi possível iniciar o WebSocket:", erro);
        }
    }

    function iniciar() {
        const modal = porId("cryptoModal");

        modal?.addEventListener("click", evento => {
            if (evento.target === modal) fecharModalCrypto();
        });

        document.addEventListener("keydown", evento => {
            if (!modal || modal.style.display !== "block") return;

            // A janela de notificações tem prioridade quando estiver aberta.
            if (porId("customModalOverlay")?.classList.contains("active")) {
                return;
            }

            if (evento.key === "Escape") {
                evento.preventDefault();
                fecharModalCrypto();
            }

            if (evento.key === "Tab") {
                const elementos = [...modal.querySelectorAll(
                    'button:not([disabled]), input:not([disabled]), ' +
                    'select:not([disabled]), a[href], [tabindex="0"]'
                )].filter(elemento => elemento.getClientRects().length);

                const primeiro = elementos[0];
                const ultimo = elementos[elementos.length - 1];

                if (!primeiro) return;

                if (evento.shiftKey && document.activeElement === primeiro) {
                    evento.preventDefault();
                    ultimo.focus();
                } else if (
                    !evento.shiftKey &&
                    document.activeElement === ultimo
                ) {
                    evento.preventDefault();
                    primeiro.focus();
                }
            }
        });

        conectarWebSocket();
    }

    window.addEventListener("pagehide", () => {
        estado.socket?.close();
    });

    // Funções utilizadas pelo HTML e pelo script.js.
    window.realizarLogin = realizarLogin;
    window.carregarCriptomoedas = carregarCriptomoedas;
    window.fecharModalCrypto = fecharModalCrypto;

    // Compatibilidade com o nome utilizado no código antigo.
    window.verEstatísticasCrypto = abrirDetalhes;

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", iniciar, { once: true });
    } else {
        iniciar();
    }
})();