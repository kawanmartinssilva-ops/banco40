/* =========================================================
   BANCO 4.0 — SCRIPT.JS
   Controla login, navegação, lançamentos, clientes,
   gráficos, relatórios e filtros.
   ========================================================= */

const CONFIG_APP = {
    nomeApp: "Banco 4.0",
    cotacaoDolarBRL: 5.0
};

let transacoes = [];
let clientes = [];
let usuarioLogado = null;
let ocultarValores = false;
let arquivoAnexoBase64 = null;
let barChart = null;
let pieChart = null;

const CHAVES = {
    transacoes: "banco40_transacoes",
    clientes: "banco40_clientes",
    usuario: "banco40_usuario"
};

/* UTILIDADES */

function lerJSON(chave, valorPadrao) {
    try {
        const valor = localStorage.getItem(chave);
        return valor ? JSON.parse(valor) : valorPadrao;
    } catch (erro) {
        console.error("Erro ao ler dados salvos:", erro);
        return valorPadrao;
    }
}

function salvarJSON(chave, valor) {
    try {
        localStorage.setItem(chave, JSON.stringify(valor));
    } catch (erro) {
        console.error("Erro ao salvar dados:", erro);
        exibirToast("Não foi possível salvar os dados.");
    }
}

function escaparTexto(texto) {
    return String(texto ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function formatarBRL(valor) {
    return Number(valor || 0).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
}

function valorSeguro(valor) {
    return ocultarValores ? "R$ ***" : formatarBRL(valor);
}

function dataAtual() {
    return new Date().toLocaleString("pt-BR");
}

/* INICIALIZAÇÃO */

document.addEventListener("DOMContentLoaded", () => {
    transacoes = lerJSON(CHAVES.transacoes, []);
    clientes = lerJSON(CHAVES.clientes, []);
    usuarioLogado = lerJSON(CHAVES.usuario, null);

    aplicarNomeAplicativo();
    iniciarRelogio();
    inicializarGraficos();
    renderizarClientes();
    atualizarTabelasEValores();

    if (usuarioLogado) {
        entrarNoPainel(usuarioLogado);
    } else {
        mostrarTelaLogin();
    }
});

function aplicarNomeAplicativo() {
    document.title = `${CONFIG_APP.nomeApp} — Sistema Financeiro`;
}

function iniciarRelogio() {
    const clock = document.getElementById("clock");

    function atualizar() {
        if (clock) {
            clock.innerText = new Date().toLocaleTimeString("pt-BR");
        }
    }

    atualizar();
    setInterval(atualizar, 1000);
}

/* LOGIN E SAÍDA */

function realizarLogin() {
    const nome = document.getElementById("adminNome").value.trim();
    const cpf = document.getElementById("adminCPF").value.trim();
    const senha = document.getElementById("adminSenha").value;

    if (!nome || !cpf || !senha) {
        exibirToast("Preencha todos os campos para entrar.");
        return;
    }

    const usuario = { nome, cpf };
    usuarioLogado = usuario;
    salvarJSON(CHAVES.usuario, usuario);

    entrarNoPainel(usuario);
    exibirToast(`Acesso concedido. Bem-vindo, ${nome}!`);
}

function entrarNoPainel(usuario) {
    const nome = escaparTexto(usuario.nome);
    const cpf = escaparTexto(usuario.cpf);

    document.getElementById("adminUserDisplay").innerText = nome;
    document.getElementById("adminCpfDisplay").innerText = `CPF: ${cpf}`;

    mostrarTelaPainel();
}

function mostrarTelaLogin() {
    document.getElementById("loginScreen").style.display = "flex";
    document.getElementById("appContainer").style.display = "none";
}

function mostrarTelaPainel() {
    document.getElementById("loginScreen").style.display = "none";
    document.getElementById("appContainer").style.display = "flex";
}

function fazerLogout() {
    usuarioLogado = null;
    localStorage.removeItem(CHAVES.usuario);
    mostrarTelaLogin();
    exibirToast("Sessão encerrada.");
}

/* NAVEGAÇÃO */

function switchView(view) {
    const abas = ["andamento", "crypto", "compras", "extrato", "clientes"];

    abas.forEach((aba) => {
        const secao = document.getElementById(`view${capitalizar(aba)}`);
        const botao = document.getElementById(`btn${capitalizar(aba)}`);

        if (secao) secao.style.display = "none";
        if (botao) botao.classList.remove("active");
    });

    const secaoAtual = document.getElementById(`view${capitalizar(view)}`);
    const botaoAtual = document.getElementById(`btn${capitalizar(view)}`);

    if (secaoAtual) secaoAtual.style.display = "block";
    if (botaoAtual) botaoAtual.classList.add("active");

    if (view === "crypto") {
        carregarCriptomoedas();
    }
}

function capitalizar(texto) {
    return texto.charAt(0).toUpperCase() + texto.slice(1);
}

/* OCULTAR VALORES */

function toggleValores() {
    ocultarValores = !ocultarValores;

    const botao = document.getElementById("btnToggleVisibilidade");
    if (botao) {
        botao.innerText = ocultarValores ? "Exibir Saldos" : "Ocultar Saldos";
    }

    atualizarTabelasEValores();
}

/* ANEXOS */

function atualizarNomeArquivo() {
    const input = document.getElementById("compFile");
    const botao = document.getElementById("lblFile");

    if (!input.files.length) {
        arquivoAnexoBase64 = null;
        if (botao) botao.innerText = "Anexo";
        return;
    }

    const arquivo = input.files[0];
    const reader = new FileReader();

    reader.onload = (evento) => {
        arquivoAnexoBase64 = evento.target.result;
    };

    reader.readAsDataURL(arquivo);

    const nomeCurto = arquivo.name.length > 12
        ? `${arquivo.name.substring(0, 12)}...`
        : arquivo.name;

    if (botao) botao.innerText = `Arquivo: ${nomeCurto}`;
}

/* LANÇAMENTOS */

function addTransacao(tipo) {
    const desc = document.getElementById("desc").value.trim();
    const val = Number(document.getElementById("val").value);
    const cat = document.getElementById("cat").value;

    if (!desc) {
        exibirToast("Digite uma descrição para o lançamento.");
        return;
    }

    if (!Number.isFinite(val) || val <= 0) {
        exibirToast("Digite um valor maior que zero.");
        return;
    }

    const novaTransacao = {
        id: Date.now(),
        data: dataAtual(),
        desc,
        val,
        cat,
        tipo,
        anexo: arquivoAnexoBase64
    };

    transacoes.unshift(novaTransacao);
    salvarJSON(CHAVES.transacoes, transacoes);

    document.getElementById("desc").value = "";
    document.getElementById("val").value = "";
    document.getElementById("lblFile").innerText = "Anexo";
    arquivoAnexoBase64 = null;

    exibirToast("Lançamento registrado com sucesso!");
    atualizarTabelasEValores();
}

function excluirTransacao(id) {
    const confirmar = confirm("Deseja realmente excluir este lançamento?");

    if (!confirmar) return;

    transacoes = transacoes.filter((item) => item.id !== id);
    salvarJSON(CHAVES.transacoes, transacoes);

    exibirToast("Lançamento excluído.");
    atualizarTabelasEValores();
}

function atualizarTabelasEValores() {
    let receitas = 0;
    let despesas = 0;
    let compras = 0;

    transacoes.forEach((item) => {
        if (item.tipo === "receita") {
            receitas += item.val;
        }

        if (item.tipo === "despesa") {
            despesas += item.val;
        }

        if (item.tipo === "compra") {
            compras += item.val;
            despesas += item.val;
        }
    });

    const saldo = receitas - despesas;

    document.getElementById("txtReceitas").innerText = valorSeguro(receitas);
    document.getElementById("txtDespesas").innerText = valorSeguro(despesas);
    document.getElementById("txtTotalCompras").innerText = valorSeguro(compras);
    document.getElementById("txtSaldo").innerText = valorSeguro(saldo);

    renderizarExtrato();
    renderizarCompras();
    atualizarGraficos(receitas, despesas, compras);
}

/* EXTRATO */

function renderizarExtrato() {
    const tbody = document.getElementById("listaExtratoBody");
    if (!tbody) return;

    if (!transacoes.length) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="empty-message">
                    Nenhuma movimentação registrada.
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = transacoes.map((item) => {
        const tipo = escaparTexto(item.tipo);
        const classeTipo = item.tipo === "receita" ? "badge-up" : item.tipo === "compra" ? "badge-compra" : "badge-down";
        const classeValor = item.tipo === "receita" ? "green" : "red";

        return `
            <tr>
                <td>${escaparTexto(item.data)}</td>
                <td>${escaparTexto(item.desc)}</td>
                <td>${escaparTexto(item.cat)}</td>
                <td><span class="badge-status ${classeTipo}">${tipo.toUpperCase()}</span></td>
                <td class="${classeValor}">${valorSeguro(item.val)}</td>
                <td>${item.anexo ? `<a href="${item.anexo}" target="_blank" rel="noopener">Ver anexo</a>` : "Sem anexo"}</td>
                <td>
                    <button type="button" class="btn-red" onclick="excluirTransacao(${item.id})">
                        Excluir
                    </button>
                </td>
            </tr>
        `;
    }).join("");
}

/* COMPRAS */

function renderizarCompras() {
    const tbody = document.getElementById("listaComprasBody");
    if (!tbody) return;

    const compras = transacoes.filter((item) => item.tipo === "compra");

    if (!compras.length) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="empty-message">
                    Nenhuma compra registrada.
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = compras.map((item) => `
        <tr>
            <td>${escaparTexto(item.data)}</td>
            <td>${escaparTexto(item.desc)}</td>
            <td>${escaparTexto(item.cat)}</td>
            <td class="orange">${valorSeguro(item.val)}</td>
            <td>${item.anexo ? `<a href="${item.anexo}" target="_blank" rel="noopener">Comprovante</a>` : "Sem anexo"}</td>
            <td><span class="badge-status badge-compra">CONCLUÍDO</span></td>
        </tr>
    `).join("");
}

/* CRIPTOMOEDAS */

async function carregarCriptomoedas() {
    const tbody = document.getElementById("listaCryptoBody");
    if (!tbody) return;

    tbody.innerHTML = `
        <tr>
            <td colspan="7" class="empty-message">
                Atualizando cotações...
            </td>
        </tr>
    `;

    try {
        const resposta = await fetch(
            "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=25&page=1&sparkline=false"
        );

        if (!resposta.ok) {
            throw new Error("Resposta inválida da API");
        }

        const moedas = await resposta.json();

        tbody.innerHTML = moedas.map((moeda, indice) => {
            const variacao = moeda.price_change_percentage_24h || 0;
            const precoBRL = moeda.current_price * CONFIG_APP.cotacaoDolarBRL;
            const classeVariacao = variacao >= 0 ? "green" : "red";
            const classeStatus = variacao >= 0 ? "badge-up" : "badge-down";
            const status = variacao >= 0 ? "ALTA" : "BAIXA";

            return `
                <tr>
                    <td>${indice + 1}</td>
                    <td>
                        <img src="${moeda.image}" alt="" class="crypto-img">
                        ${escaparTexto(moeda.name)} (${escaparTexto(moeda.symbol.toUpperCase())})
                    </td>
                    <td>US$ ${Number(moeda.current_price).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</td>
                    <td>${formatarBRL(precoBRL)}</td>
                    <td class="${classeVariacao}">${variacao.toFixed(2)}%</td>
                    <td><span class="badge-status ${classeStatus}">${status}</span></td>
                    <td>
                        <button type="button" class="btn-green" onclick="abrirModal('Detalhes da criptomoeda', 'Cotação de ${escaparTexto(moeda.name)}: US$ ${Number(moeda.current_price).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}')">
                            Detalhes
                        </button>
                    </td>
                </tr>
            `;
        }).join("");

    } catch (erro) {
        console.error(erro);
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="empty-message">
                    Não foi possível carregar as cotações agora.
                </td>
            </tr>
        `;
    }
}

/* CLIENTES */

function cadastrarCliente() {
    const nome = document.getElementById("cliNome").value.trim();
    const documento = document.getElementById("cliCPF").value.trim();
    const email = document.getElementById("cliEmail").value.trim();

    if (!nome || !documento) {
        exibirToast("Preencha o nome e o documento do cliente.");
        return;
    }

    clientes.push({
        id: Date.now(),
        nome,
        documento,
        email,
        status: "Ativo"
    });

    salvarJSON(CHAVES.clientes, clientes);

    document.getElementById("cliNome").value = "";
    document.getElementById("cliCPF").value = "";
    document.getElementById("cliEmail").value = "";

    exibirToast("Cliente cadastrado com sucesso!");
    renderizarClientes();
}

function excluirCliente(id) {
    const confirmar = confirm("Deseja realmente excluir este cliente?");

    if (!confirmar) return;

    clientes = clientes.filter((cliente) => cliente.id !== id);
    salvarJSON(CHAVES.clientes, clientes);

    exibirToast("Cliente excluído.");
    renderizarClientes();
}

function renderizarClientes() {
    const tbody = document.getElementById("listaClientesBody");
    if (!tbody) return;

    if (!clientes.length) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="empty-message">
                    Nenhum cliente cadastrado.
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = clientes.map((cliente) => `
        <tr>
            <td><strong>${escaparTexto(cliente.nome)}</strong></td>
            <td>${escaparTexto(cliente.documento)}</td>
            <td>${cliente.email ? escaparTexto(cliente.email) : "Sem e-mail"}</td>
            <td><span class="badge-status badge-up">${escaparTexto(cliente.status)}</span></td>
            <td>
                <button type="button" class="btn-red" onclick="excluirCliente(${cliente.id})">
                    Excluir
                </button>
            </td>
        </tr>
    `).join("");
}

/* GRÁFICOS */

function inicializarGraficos() {
    const canvasBarra = document.getElementById("barChart");
    const canvasPizza = document.getElementById("pieChart");

    if (!canvasBarra || !canvasPizza || typeof Chart === "undefined") {
        return;
    }

    barChart = new Chart(canvasBarra, {
        type: "bar",
        data: {
            labels: ["Entradas", "Saídas", "Compras"],
            datasets: [{
                label: "Total em reais",
                data: [0, 0, 0],
                backgroundColor: ["#10b981", "#ef4444", "#f59e0b"]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            }
        }
    });

    pieChart = new Chart(canvasPizza, {
        type: "doughnut",
        data: {
            labels: ["Entradas", "Despesas", "Compras"],
            datasets: [{
                data: [0, 0, 0],
                backgroundColor: ["#10b981", "#ef4444", "#f59e0b"]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });
}

function atualizarGraficos(receitas, despesas, compras) {
    if (!barChart || !pieChart) return;

    barChart.data.datasets[0].data = [receitas, despesas, compras];
    barChart.update();

    pieChart.data.datasets[0].data = [receitas, despesas, compras];
    pieChart.update();
}

/* RELATÓRIOS */

function exportarCSV() {
    if (!transacoes.length) {
        exibirToast("Não há movimentações para exportar.");
        return;
    }

    let csv = "Data;Descrição;Categoria;Tipo;Valor\n";

    transacoes.forEach((item) => {
        csv += `${item.data};${item.desc};${item.cat};${item.tipo};${item.val}\n`;
    });

    baixarArquivo(csv, "extrato_financeiro.csv", "text/csv;charset=utf-8;");
    exibirToast("Arquivo CSV gerado.");
}

function exportarPDF() {
    if (!transacoes.length) {
        exibirToast("Não há movimentações para exportar.");
        return;
    }

    if (typeof window.jspdf === "undefined") {
        exibirToast("A biblioteca de PDF não carregou.");
        return;
    }

    const { jsPDF } = window.jspdf;
    const documento = new jsPDF();
    let linha = 20;

    documento.setFontSize(16);
    documento.text("Relatório Financeiro", 10, 10);

    transacoes.forEach((item) => {
        if (linha > 280) {
            documento.addPage();
            linha = 20;
        }

        documento.setFontSize(10);
        documento.text(
            `${item.data} — ${item.desc} — ${formatarBRL(item.val)} (${item.tipo})`,
            10,
            linha
        );

        linha += 10;
    });

    documento.save("relatorio_financeiro.pdf");
    exibirToast("Relatório PDF gerado.");
}

function baixarArquivo(conteudo, nome, tipo) {
    const blob = new Blob([conteudo], { type: tipo });
    const link = document.createElement("a");

    link.href = URL.createObjectURL(blob);
    link.download = nome;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
}

/* AVISOS E JANELAS */

function exibirToast(mensagem) {
    const container = document.getElementById("toastContainer");
    if (!container) return;

    const aviso = document.createElement("div");
    aviso.className = "toast";
    aviso.innerText = mensagem;

    container.appendChild(aviso);

    setTimeout(() => aviso.remove(), 3500);
}

function abrirModal(titulo, mensagem) {
    const elementoTitulo = document.getElementById("modalTitle");
    const elementoMensagem = document.getElementById("modalMessage");
    const janela = document.getElementById("customModalOverlay");

    if (!elementoTitulo || !elementoMensagem || !janela) return;

    elementoTitulo.innerText = titulo;
    elementoMensagem.innerText = mensagem;
    janela.classList.add("active");
}

function fecharModal() {
    document.getElementById("customModalOverlay").classList.remove("active");
}

/* FILTROS */

function filtrarExtrato() {
    filtrarTabela("searchExtrato", "listaExtratoBody");
}

function filtrarCompras() {
    filtrarTabela("searchCompras", "listaComprasBody");
}

function filtrarTabela(idCampo, idTabela) {
    const campo = document.getElementById(idCampo);
    const tbody = document.getElementById(idTabela);

    if (!campo || !tbody) return;

    const busca = campo.value.toLowerCase().trim();
    const linhas = tbody.querySelectorAll("tr");

    linhas.forEach((linha) => {
        const texto = linha.innerText.toLowerCase();
        linha.style.display = texto.includes(busca) ? "" : "none";
    });
}

/* FUNÇÕES DISPONÍVEIS PARA OS BOTÕES DO HTML */

Object.assign(window, {
    realizarLogin,
    fazerLogout,
    switchView,
    toggleValores,
    atualizarNomeArquivo,
    addTransacao,
    carregarCriptomoedas,
    cadastrarCliente,
    exportarCSV,
    exportarPDF,
    filtrarExtrato,
    filtrarCompras,
    abrirModal,
    fecharModal,
    excluirTransacao,
    excluirCliente
});