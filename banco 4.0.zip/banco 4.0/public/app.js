
let graficosCrypto = {};
let criptosAtuais = [];

"use strict";

(() => {
    let criptosAtuais = [];
    let carregandoCriptos = false;
    let ultimaAtualizacao = 0;

    const INTERVALO_MINIMO = 60_000;
    const TEMPO_LIMITE = 15_000;

    function avisar(mensagem) {
        if (typeof window.exibirToast === "function") {
            window.exibirToast(mensagem);
        } else {
            window.alert(mensagem);
        }
    }

    function formatarMoeda(valor, moeda) {
        if (typeof valor !== "number" || !Number.isFinite(valor)) {
            return "Indisponível";
        }

        return new Intl.NumberFormat("pt-BR", {
            style: "currency",
            currency: moeda,
            maximumFractionDigits: 8
        }).format(valor);
    }

    function mostrarMensagemTabela(mensagem) {
        const tabela = document.getElementById("listaCryptoBody");
        if (!tabela) return;

        const linha = document.createElement("tr");
        const celula = document.createElement("td");

        celula.colSpan = 7;
        celula.style.textAlign = "center";
        celula.textContent = mensagem;

        linha.appendChild(celula);
        tabela.replaceChildren(linha);
    }

    function adicionarCelula(linha, texto, classe = "") {
        const celula = document.createElement("td");
        celula.textContent = texto;

        if (classe) celula.className = classe;

        linha.appendChild(celula);
        return celula;
    }

    function renderizarCriptomoedas() {
        const tabela = document.getElementById("listaCryptoBody");
        if (!tabela) return;

        if (criptosAtuais.length === 0) {
            mostrarMensagemTabela("Nenhuma criptomoeda encontrada.");
            return;
        }

        const fragmento = document.createDocumentFragment();

        criptosAtuais.forEach((moeda, indice) => {
            const linha = document.createElement("tr");

            const nome = String(moeda.name ?? "Sem nome");
            const simbolo = String(moeda.symbol ?? "").toUpperCase();

            const variacao = moeda.price_change_percentage_24h;
            const variacaoValida =
                typeof variacao === "number" &&
                Number.isFinite(variacao);

            adicionarCelula(linha, String(indice + 1));
            adicionarCelula(linha, `${nome} (${simbolo})`);

            adicionarCelula(
                linha,
                formatarMoeda(moeda.current_price, "USD")
            );

            // Não apresenta uma conversão fixa como cotação real.
            adicionarCelula(linha, "Não consultado");

            adicionarCelula(
                linha,
                variacaoValida
                    ? `${variacao.toFixed(2)}%`
                    : "Indisponível",
                variacaoValida
                    ? (variacao >= 0 ? "green" : "red")
                    : ""
            );

            adicionarCelula(
                linha,
                !variacaoValida
                    ? "Sem dados"
                    : variacao > 0
                        ? "Alta"
                        : variacao < 0
                            ? "Baixa"
                            : "Estável"
            );

            const celulaAcao = adicionarCelula(linha, "");
            const botao = document.createElement("button");

            botao.type = "button";
            botao.className = "btn-green";
            botao.textContent = "Detalhes";

            botao.addEventListener("click", () => {
                const mensagem =
                    `${nome} (${simbolo}) — ` +
                    `Preço: ${formatarMoeda(moeda.current_price, "USD")}. ` +
                    `Variação em 24h: ${
                        variacaoValida
                            ? `${variacao.toFixed(2)}%`
                            : "indisponível"
                    }.`;

                if (typeof window.abrirModal === "function") {
                    window.abrirModal("Mercado Cripto", mensagem);
                } else {
                    avisar(mensagem);
                }
            });

            celulaAcao.appendChild(botao);
            fragmento.appendChild(linha);
        });

        tabela.replaceChildren(fragmento);
    }

    async function carregarCriptomoedas() {
        if (!document.getElementById("listaCryptoBody")) return;
        if (carregandoCriptos) return;

        const cacheRecente =
            criptosAtuais.length > 0 &&
            Date.now() - ultimaAtualizacao < INTERVALO_MINIMO;

        if (cacheRecente) {
            renderizarCriptomoedas();
            return;
        }

        carregandoCriptos = true;

        if (criptosAtuais.length === 0) {
            mostrarMensagemTabela("Carregando cotações...");
        }

        const controlador = new AbortController();
        const temporizador = setTimeout(
            () => controlador.abort(),
            TEMPO_LIMITE
        );

        try {
            const parametros = new URLSearchParams({
                vs_currency: "usd",
                order: "market_cap_desc",
                per_page: "25",
                page: "1",
                sparkline: "false"
            });

            const resposta = await fetch(
                `https://api.coingecko.com/api/v3/coins/markets?${parametros}`,
                { signal: controlador.signal }
            );

            if (!resposta.ok) {
                if (resposta.status === 429) {
                    throw new Error(
                        "Limite de consultas atingido. Tente novamente mais tarde."
                    );
                }

                throw new Error(
                    `A consulta retornou o erro HTTP ${resposta.status}.`
                );
            }

            const dados = await resposta.json();

            if (
                !Array.isArray(dados) ||
                !dados.every(item =>
                    item !== null &&
                    typeof item === "object" &&
                    typeof item.id === "string"
                )
            ) {
                throw new Error("A API retornou dados inesperados.");
            }

            criptosAtuais = dados;
            ultimaAtualizacao = Date.now();

            renderizarCriptomoedas();
        } catch (erro) {
            console.error("Erro ao consultar criptomoedas:", erro);

            const mensagem = erro.name === "AbortError"
                ? "A consulta demorou demais. Tente novamente."
                : erro.message || "Não foi possível consultar as cotações.";

            if (criptosAtuais.length > 0) {
                renderizarCriptomoedas();
                avisar(`${mensagem} Exibindo os últimos dados carregados.`);
            } else {
                mostrarMensagemTabela(mensagem);
            }
        } finally {
            clearTimeout(temporizador);
            carregandoCriptos = false;
        }
    }

    function realizarLogin() {
        const campoNome = document.getElementById("adminNome");
        const campoCPF = document.getElementById("adminCPF");
        const campoSenha = document.getElementById("adminSenha");
        const telaLogin = document.getElementById("loginScreen");
        const painel = document.getElementById("appContainer");

        if (
            !campoNome || !campoCPF || !campoSenha ||
            !telaLogin || !painel
        ) {
            console.error("Elementos do login não encontrados no HTML.");
            avisar("A tela de login está incompleta.");
            return;
        }

        const nome = campoNome.value.trim();
        const cpf = campoCPF.value.replace(/\D/g, "");
        const senha = campoSenha.value;

        if (!nome || !cpf || !senha) {
            avisar("Preencha nome, CPF e senha.");
            return;
        }

        if (cpf.length !== 11) {
            avisar("O CPF deve ter 11 números.");
            return;
        }

        // Demonstração local: não autentica uma conta no servidor.
        const nomeExibido = document.getElementById("adminUserDisplay");
        const cpfExibido = document.getElementById("adminCpfDisplay");

        if (nomeExibido) nomeExibido.textContent = nome;
        if (cpfExibido) {
            cpfExibido.textContent = `CPF: ***.***.***-${cpf.slice(-2)}`;
        }

        campoSenha.value = "";

        telaLogin.style.display = "none";
        painel.style.display = "flex";

        if (typeof window.renderizarClientes === "function") {
            window.renderizarClientes();
        }

        avisar(`Modo de demonstração iniciado. Bem-vindo, ${nome}!`);
    }

    // Disponibiliza as funções para os botões do HTML.
    window.realizarLogin = realizarLogin;
    window.carregarCriptomoedas = carregarCriptomoedas;
})();

